/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'sk', {
	fontSize: {
		label: 'Veľkosť',
		voiceLabel: 'Veľkosť písma',
		panelTitle: 'Veľkosť písma'
	},
	label: 'Písmo',
	panelTitle: 'Názov písma',
	voiceLabel: 'Písmo'
} );
